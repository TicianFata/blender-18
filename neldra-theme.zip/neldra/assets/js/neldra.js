/* ==========================================================================
   NELDRA — interactions
   Vanilla, dependency-free, progressive-enhancement.
   Production note: the split-screen + reveals mirror what GSAP/ScrollTrigger
   and Lenis will drive in the WordPress build (see /docs/04-animations.md).
   ========================================================================== */
(function () {
  "use strict";

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var coarse = window.matchMedia("(pointer: coarse)").matches;
  var $  = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* ----------------------------------------------------------------------
     Split-screen hero
     ---------------------------------------------------------------------- */
  function initHero() {
    var hero = $("[data-hero]");
    if (!hero) return;
    var panels = $$(".panel", hero);

    function activate(name) {
      hero.setAttribute("data-hover", name);
      panels.forEach(function (p) {
        p.classList.toggle("is-active", p.getAttribute("data-panel") === name);
      });
    }
    function clear() {
      hero.removeAttribute("data-hover");
      panels.forEach(function (p) { p.classList.remove("is-active"); });
    }

    panels.forEach(function (panel) {
      var name = panel.getAttribute("data-panel");

      if (!coarse) {
        panel.addEventListener("mouseenter", function () { activate(name); });
        panel.addEventListener("focus", function () { activate(name); });
      }

      // Touch: first tap previews, second tap enters.
      panel.addEventListener("click", function (e) {
        if (coarse && !panel.classList.contains("is-active")) {
          e.preventDefault();
          activate(name);
        }
      });

      // Subtle pointer parallax on the media (desktop, motion on)
      if (!coarse && !reduce) {
        var media = $(".panel__media", panel);
        panel.addEventListener("mousemove", function (e) {
          var r = panel.getBoundingClientRect();
          var dx = (e.clientX - r.left) / r.width - 0.5;
          var dy = (e.clientY - r.top) / r.height - 0.5;
          if (media) media.style.transform = "scale(1.05) translate(" + (dx * -14) + "px," + (dy * -14) + "px)";
        });
        panel.addEventListener("mouseleave", function () {
          if (media) media.style.transform = "";
        });
      }
    });

    if (!coarse) hero.addEventListener("mouseleave", clear);
  }

  /* ----------------------------------------------------------------------
     Header: overlay -> solid, hide on scroll down / show on scroll up
     ---------------------------------------------------------------------- */
  function initHeader() {
    var header = $("[data-header]");
    if (!header) return;
    var overlayStart = header.classList.contains("site-header--overlay");
    var hero = $("[data-hero]");
    var threshold = hero ? hero.offsetHeight - 120 : 120;
    var last = 0;

    function onScroll() {
      var y = window.pageYOffset;
      if (overlayStart) {
        if (y > threshold) {
          header.classList.remove("site-header--overlay");
          header.classList.add("site-header--solid");
        } else {
          header.classList.add("site-header--overlay");
          header.classList.remove("site-header--solid");
        }
      }
      // hide/show
      if (y > last && y > (overlayStart ? threshold + 200 : 200)) {
        header.classList.add("is-hidden");
      } else {
        header.classList.remove("is-hidden");
      }
      last = y;
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ----------------------------------------------------------------------
     Scroll reveals
     ---------------------------------------------------------------------- */
  function initReveals() {
    var items = $$("[data-reveal]");
    if (!items.length) return;
    if (reduce || !("IntersectionObserver" in window)) {
      items.forEach(function (el) { el.classList.add("is-visible"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("is-visible");
          io.unobserve(en.target);
        }
      });
    }, { rootMargin: "0px 0px -12% 0px", threshold: 0.08 });
    items.forEach(function (el) { io.observe(el); });
  }

  /* ----------------------------------------------------------------------
     Overlays: menu, search, cart drawer
     ---------------------------------------------------------------------- */
  function initOverlays() {
    var scrim = $("[data-scrim]");
    function open(el) { if (el) el.classList.add("is-open"); if (scrim) scrim.classList.add("is-open"); document.documentElement.style.overflow = "hidden"; }
    function close() {
      $$(".overlay, .drawer").forEach(function (el) { el.classList.remove("is-open"); });
      if (scrim) scrim.classList.remove("is-open");
      document.documentElement.style.overflow = "";
    }
    $$("[data-open]").forEach(function (btn) {
      btn.addEventListener("click", function () { open($("#" + btn.getAttribute("data-open"))); });
    });
    $$("[data-close]").forEach(function (btn) { btn.addEventListener("click", close); });
    if (scrim) scrim.addEventListener("click", close);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    // focus the search field when the search overlay opens
    var searchBtn = $('[data-open="search-overlay"]');
    if (searchBtn) searchBtn.addEventListener("click", function () {
      setTimeout(function () { var i = $("#search-overlay .search-input"); if (i) i.focus(); }, 300);
    });
  }

  /* ----------------------------------------------------------------------
     Grid density switch (shop / collection)
     ---------------------------------------------------------------------- */
  function initGridControl() {
    var control = $("[data-grid-control]");
    var grid = $("[data-grid]");
    if (!control || !grid) return;
    var stored = localStorage.getItem("neldra-cols");
    if (stored) setCols(stored);

    function setCols(n) {
      grid.className = grid.className.replace(/grid--\d/g, "").trim();
      grid.classList.add("grid", "grid--" + n);
      $$("button", control).forEach(function (b) {
        b.setAttribute("aria-pressed", b.getAttribute("data-cols") === String(n) ? "true" : "false");
      });
      localStorage.setItem("neldra-cols", n);
    }
    $$("button", control).forEach(function (b) {
      b.addEventListener("click", function () { setCols(b.getAttribute("data-cols")); });
    });
  }

  /* ----------------------------------------------------------------------
     Accordion (product info)
     ---------------------------------------------------------------------- */
  function initAccordion() {
    $$(".acc__head").forEach(function (head) {
      head.addEventListener("click", function () {
        var item = head.closest(".acc__item");
        var body = $(".acc__body", item);
        var open = item.getAttribute("aria-expanded") === "true";
        item.setAttribute("aria-expanded", open ? "false" : "true");
        body.style.maxHeight = open ? "0px" : (body.scrollHeight + "px");
      });
    });
  }

  /* ----------------------------------------------------------------------
     Quantity stepper
     ---------------------------------------------------------------------- */
  function initQty() {
    $$(".qty").forEach(function (q) {
      var input = $("input", q);
      $$("button", q).forEach(function (b) {
        b.addEventListener("click", function () {
          var v = parseInt(input.value, 10) || 1;
          v += b.getAttribute("data-step") === "up" ? 1 : -1;
          input.value = Math.max(1, v);
        });
      });
    });
  }

  /* ----------------------------------------------------------------------
     Lightbox / image zoom (product gallery)
     Click any gallery image -> full-screen single image, with ✕ close and
     prev/next arrows (also arrow keys + Escape).
     ---------------------------------------------------------------------- */
  function initLightbox() {
    // Collect every product image (gallery + the detail section) in order.
    var imgs = [];
    $$(".pdp__gallery, .pdp-details__stack").forEach(function (c) {
      imgs = imgs.concat($$("img", c));
    });
    if (!imgs.length) return;

    var slides = imgs.map(function (im) {
      return { src: im.getAttribute("src"), alt: im.getAttribute("alt") || "" };
    });

    var lb = document.createElement("div");
    lb.className = "lightbox";
    lb.setAttribute("role", "dialog");
    lb.setAttribute("aria-modal", "true");
    lb.setAttribute("aria-label", "Image viewer");
    lb.innerHTML =
      '<button class="lightbox__close" data-lb-close aria-label="Close">Close &times;</button>' +
      '<button class="lightbox__nav lightbox__nav--prev" data-lb-prev aria-label="Previous image"></button>' +
      '<figure class="lightbox__stage"><img alt=""></figure>' +
      '<button class="lightbox__nav lightbox__nav--next" data-lb-next aria-label="Next image"></button>' +
      '<span class="lightbox__count"></span>';
    document.body.appendChild(lb);

    var big   = $("img", lb);
    var count = $(".lightbox__count", lb);
    var idx = 0;

    function show(i) {
      idx = (i + slides.length) % slides.length;
      big.classList.remove("is-ready");
      var s = slides[idx];
      var tmp = new Image();
      tmp.onload = function () { big.classList.add("is-ready"); };
      big.src = s.src;
      big.alt = s.alt;
      tmp.src = s.src;
      if (tmp.complete) big.classList.add("is-ready");
      count.textContent = (idx + 1) + " / " + slides.length;
    }
    function open(i) {
      show(i);
      lb.classList.add("is-open");
      document.documentElement.style.overflow = "hidden";
    }
    function close() {
      lb.classList.remove("is-open");
      document.documentElement.style.overflow = "";
    }

    imgs.forEach(function (im, i) {
      im.addEventListener("click", function (e) { e.preventDefault(); open(i); });
    });
    $("[data-lb-close]", lb).addEventListener("click", close);
    $("[data-lb-prev]", lb).addEventListener("click", function (e) { e.stopPropagation(); show(idx - 1); });
    $("[data-lb-next]", lb).addEventListener("click", function (e) { e.stopPropagation(); show(idx + 1); });
    lb.addEventListener("click", function (e) {
      // click on the empty backdrop (not a control or the image) closes
      if (e.target === lb || e.target.classList.contains("lightbox__stage")) close();
    });
    document.addEventListener("keydown", function (e) {
      if (!lb.classList.contains("is-open")) return;
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") show(idx - 1);
      else if (e.key === "ArrowRight") show(idx + 1);
    });
  }

  /* ----------------------------------------------------------------------
     Parallax — subtle scroll translation for oversized images.
     Reference position is the (untransformed) parent frame, so there is no
     feedback loop. Disabled under reduced motion.
     ---------------------------------------------------------------------- */
  function initParallax() {
    if (reduce) return;
    var els = $$("[data-parallax]");
    if (!els.length) return;
    var ticking = false;

    function update() {
      var vh = window.innerHeight;
      els.forEach(function (el) {
        var host = el.parentElement;
        var r = host.getBoundingClientRect();
        if (r.bottom < -100 || r.top > vh + 100) return;
        var speed = parseFloat(el.getAttribute("data-parallax")) || 0.1;
        var y = -(r.top + r.height / 2 - vh / 2) * speed;
        var max = r.height * 0.12;
        if (y > max) y = max; else if (y < -max) y = -max;
        el.style.transform = "translate3d(0," + y.toFixed(1) + "px,0)";
      });
      ticking = false;
    }
    function onScroll() {
      if (!ticking) { requestAnimationFrame(update); ticking = true; }
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    update();
  }

  /* ----------------------------------------------------------------------
     Collections — 3-panel split that expands toward the pointer
     ---------------------------------------------------------------------- */
  function initCollections() {
    var split = $(".collections-split");
    if (!split) return;
    var panels = $$(".cpanel", split);
    if (coarse) return; // touch: keep equal; a tap navigates

    function activate(panel) {
      split.classList.add("is-hovering");
      panels.forEach(function (p) { p.classList.toggle("is-active", p === panel); });
    }
    function clear() {
      split.classList.remove("is-hovering");
      panels.forEach(function (p) { p.classList.remove("is-active"); });
    }
    panels.forEach(function (panel) {
      panel.addEventListener("mouseenter", function () { activate(panel); });
      panel.addEventListener("focus", function () { activate(panel); });
      panel.addEventListener("blur", clear);
    });
    split.addEventListener("mouseleave", clear);
  }

  /* ----------------------------------------------------------------------
     Newsletter / email collector (prototype: confirm inline)
     ---------------------------------------------------------------------- */
  function initNewsletter() {
    $$("[data-newsletter]").forEach(function (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var input = $(".newsletter__input", form);
        if (input && input.checkValidity && !input.checkValidity()) {
          input.reportValidity();
          return;
        }
        var section = form.parentElement;
        form.style.display = "none";
        var msg = $(".newsletter__msg", section);
        if (!msg) {
          msg = document.createElement("p");
          msg.className = "newsletter__msg";
          section.appendChild(msg);
        }
        msg.textContent = "Thank you — you're on the list.";
      });
    });
  }

  /* ----------------------------------------------------------------------
     Language switch (visual only in the prototype)
     ---------------------------------------------------------------------- */
  function initLang() {
    var sw = $("[data-lang]");
    if (!sw) return;
    $$("button", sw).forEach(function (b) {
      b.addEventListener("click", function () {
        $$("button", sw).forEach(function (x) { x.setAttribute("aria-pressed", "false"); });
        b.setAttribute("aria-pressed", "true");
      });
    });
  }

  /* ----------------------------------------------------------------------
     Selectable option chips (.swatch) — finishes, materials, project type,
     scale, needs. Single-select within the closest group by default; add
     data-multi on the group for multi-select (e.g. "What do you need?").
     ---------------------------------------------------------------------- */
  function initSwatches() {
    $$(".swatch").forEach(function (sw) {
      // Avoid submitting a surrounding form when a chip is clicked.
      if (!sw.getAttribute("type")) sw.setAttribute("type", "button");

      sw.addEventListener("click", function (e) {
        e.preventDefault();
        var group = sw.closest("[data-swatch-group]") || sw.closest(".pdp__row") || sw.parentElement;
        var multi = group.hasAttribute("data-multi");
        if (multi) {
          var on = sw.getAttribute("aria-pressed") === "true";
          sw.setAttribute("aria-pressed", on ? "false" : "true");
        } else {
          $$(".swatch", group).forEach(function (s) { s.setAttribute("aria-pressed", "false"); });
          sw.setAttribute("aria-pressed", "true");
        }
      });
    });
  }

  /* ---------------------------------------------------------------------- */
  document.addEventListener("DOMContentLoaded", function () {
    initHero();
    initHeader();
    initReveals();
    initOverlays();
    initGridControl();
    initAccordion();
    initQty();
    initSwatches();
    initLightbox();
    initCollections();
    initParallax();
    initNewsletter();
    initLang();
  });
})();
